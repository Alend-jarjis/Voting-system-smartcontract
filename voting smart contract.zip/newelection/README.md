
 #voting system
 This contract lets voters to vote in a specified time and see the results of election at the end of election. the time is specified by the contractor by the time it added to the contract.

**Full Free Video Tutorial:**
https://youtu.be/3681ZYbDSSk


Follow the steps below to download, install, and run this project.

## Dependencies 
- NPM  
- Truffle
- Ganache
- IPFS
- Metamask


## Step 1. Clone the project
`git clone https://github.com/Alend-jarjis/Voting-system-smartcontract'

## Step 2. Install dependencies

## Step 3. Start Ganache
 
## Step 4. Compile & Deploy Election Smart Contract
`$ truffle migrate --reset`
You must migrate the election smart contract each time your restart ganache.

## Step 5. Configure Metamask
See free video tutorial for full explanation of these steps:
- Unlock Metamask
- Connect metamask to your local Etherum blockchain provided by Ganache.
- Import an account provided by ganache.

## Step 6. Run the Front End Application
`$ npm run dev`
Visit this URL in your browser: http://localhost:3000
 step 7. start IPFS: after following steps for instalation that should have (ipfs init), 
 -then run: ipfs daemon.
 -let the terminal open, and open another terminal to create a directory in for IPFS containing important files. I have already create it: (dist).
 - find peers in network, command: (ipfs swarm peers).
 -then add to IPFS; ipfs add -r foldername(dist).
 -start publishing:copy the last hash and past it after command;(ipfs name publish)
 -copy the hash with the \ipfs\ and paste it in (gatweway.ipfs.io).
  

