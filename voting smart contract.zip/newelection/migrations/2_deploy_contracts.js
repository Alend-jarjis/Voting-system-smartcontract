var Elect= artifacts.require("./Elect.sol");

module.exports = function(deployer) {
  deployer.deploy(Elect);
};
